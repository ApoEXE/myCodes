#!/bin/bash
export DISPLAY=:0
xrandr --output HDMI-0 --mode 1280x720 --rate 59.94
exec /home/tx2/mss/vn_arhud/arhud
