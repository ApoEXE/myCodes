#!/bin/bash
/usr/bin/python3 /home/ubuntu/sensorDataloggerSerial.py

